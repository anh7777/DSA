package Hw1_22001235_NguyenNgocAnh.Exercise9;

class Record {
    int value;
    int index;

    public Record(int value, int index) {
        this.value = value;
        this.index = index;
    }
}